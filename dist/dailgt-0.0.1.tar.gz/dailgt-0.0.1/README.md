# danalysis
A simple python package for data analysis, curve fitting and plotting physics simulation data.